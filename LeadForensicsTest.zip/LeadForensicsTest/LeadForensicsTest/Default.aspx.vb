﻿Public Class _Default
    Inherits Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then

            Dim db As New NBAEntities
            Dim WinLosses = db.sp_selectwinlosses().ToList

            NBAData.DataSource = WinLosses
            NBAData.DataBind()

            BindBC("Won")
        End If
    End Sub

    Protected Sub BindBC(ByVal Show As String)

        sh1.Text = If(Show = "Won", "wins", "losses")

        Dim db As New NBAEntities
        Dim WinLosses = db.sp_selectwinlosses().ToList

        Dim BarChartData = If(Show = "Won", (From x In WinLosses Select x.Won, x.NAME).ToList, (From x In WinLosses Select x.Lost, x.NAME).ToList)
        TeamsBarChart.DataBindTable(BarChartData, "NAME")

        TeamsBarChart.DataBind()

    End Sub

    Private Sub NBAData_Sorting(sender As Object, e As GridViewSortEventArgs) Handles NBAData.Sorting
        BindBC(e.SortExpression)
    End Sub
End Class