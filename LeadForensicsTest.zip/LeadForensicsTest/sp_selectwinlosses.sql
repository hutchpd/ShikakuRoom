USE [NBA]
GO

/****** Object:  StoredProcedure [dbo].[sp_selectwinlosses]    Script Date: 06/01/2015 23:05:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:		<Paul Hutchinson>
-- Create date: <06-Jan-2014>
-- Description:	<Selects the number of wins and losses for all teams in all games>
-- =============================================
CREATE PROCEDURE [dbo].[sp_selectwinlosses]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT teams.NAME, 
       logo, 
       url, 
       Away.games + Home.games                          Games, 
       Away.wins + Home.wins                            Won, 
       Away.games + Home.games - Away.wins - Home.games Lost, 
       Home.games                                       [Played Home], 
       Away.games                                       [Played Away], 
       MVP.NAME                                         MVP, 
       LastGame.gamedatetime                            [Last Game Date], 
       BiggestLoss.score                                BiggestLoss, 
       BiggestWin.score                                 BiggestWin 
FROM   [dbo].[teams] 
       CROSS apply (SELECT Sum(CASE 
                                 WHEN awayscore > homescore THEN 1 
                                 ELSE 0 
                               END) Wins, 
                           Count(*) Games 
                    FROM   [NBA].[dbo].[games] 
                    WHERE  games.awayteamid = teams.teamid) Away 
       CROSS apply (SELECT Sum(CASE 
                                 WHEN homescore > awayscore THEN 1 
                                 ELSE 0 
                               END) Wins, 
                           Count(*) Games 
                    FROM   [NBA].[dbo].[games] 
                    WHERE  games.hometeamid = teams.teamid) Home 
       CROSS apply (SELECT TOP(1) NAME 
                    FROM   [dbo].[players] 
                           INNER JOIN [dbo].[team_player] 
                                   ON team_player.playerid = players.playerid 
                           INNER JOIN [dbo].[games] 
                                   ON games.mvpplayerid = team_player.playerid 
                    WHERE  team_player.teamid = teams.teamid 
                    GROUP  BY NAME 
                    ORDER  BY Count(*) DESC) MVP 
       CROSS apply (SELECT TOP(1) CASE 
                                    WHEN games.hometeamid = teams.teamid THEN 
                                    homescore - awayscore 
                                    ELSE awayscore - homescore 
                                  END diff, 
                                  CASE 
                                    WHEN games.hometeamid = teams.teamid THEN 
                                    Concat( 
                                    CONVERT(NVARCHAR(3), homescore), ' - ', 
                                    CONVERT(NVARCHAR(3), awayscore)) 
                                    ELSE Concat(CONVERT(NVARCHAR(3), awayscore), 
                                         ' - ', 
                                         CONVERT(NVARCHAR(3), homescore)) 
                                  END score 
                    FROM   [dbo].[games] 
                    WHERE  games.hometeamid = teams.teamid 
                            OR games.awayteamid = teams.teamid 
                    ORDER  BY diff ASC) BiggestLoss 
       CROSS apply (SELECT TOP(1) CASE 
                                    WHEN games.hometeamid = teams.teamid THEN 
                                    homescore - awayscore 
                                    ELSE awayscore - homescore 
                                  END diff, 
                                  CASE 
                                    WHEN games.hometeamid = teams.teamid THEN 
                                    Concat( 
                                    CONVERT(NVARCHAR(3), homescore), ' - ', 
                                    CONVERT(NVARCHAR(3), awayscore)) 
                                    ELSE Concat(CONVERT(NVARCHAR(3), awayscore), 
                                         ' - ', 
                                         CONVERT(NVARCHAR(3), homescore)) 
                                  END score 
                    FROM   [dbo].[games] 
                    WHERE  games.hometeamid = teams.teamid 
                            OR games.awayteamid = teams.teamid 
                    ORDER  BY diff DESC) BiggestWin 
       CROSS apply (SELECT TOP(1) gamedatetime 
                    FROM   [dbo].[games] 
                    WHERE  games.hometeamid = teams.teamid 
                            OR games.awayteamid = teams.teamid 
                    ORDER  BY gamedatetime DESC) LastGame 

END


GO


